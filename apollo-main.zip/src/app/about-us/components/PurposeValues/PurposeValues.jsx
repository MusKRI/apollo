const PurposeValues = () => {
  return <div>Purpose & Values</div>;
};

export default PurposeValues;
