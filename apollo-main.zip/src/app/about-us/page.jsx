import AboutUsBanner from "./components/Banner/Banner";
import WhoWeAre from "./components/WhoWeAre/WhoWeAre";

const AboutUs = () => {
  return (
    <div className="">
      <AboutUsBanner />

      <WhoWeAre />
    </div>
  );
};

export default AboutUs;
